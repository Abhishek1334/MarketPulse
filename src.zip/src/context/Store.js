import { create } from "zustand";

const useStore = create((set, get) => ({
	// ---- Auth State ----
	user: null,
	login: ({ user, token }) => {
		const userWithToken = { ...user, token };
		localStorage.setItem("authUser", JSON.stringify(userWithToken));
		set({ user: userWithToken });
	},
	logout: () => {
		localStorage.removeItem("authUser");
		set({ user: null });
	},
	initializeUser: () => {
		const storedUser = localStorage.getItem("authUser");
		if (storedUser) {
			set({ user: JSON.parse(storedUser) });
		} else {
			set({ user: null });
		}
	},
	isLoggedIn: () => !!get().user,

	// ---- Watchlists State ----
	watchlists: [],
	setWatchlists: (newWatchlists) => set({ watchlists: newWatchlists }),
	addWatchlist: (newWatchlist) =>
		set((state) => ({
			watchlists: [...state.watchlists, newWatchlist],
		})),
	deleteWatchlist: (id) =>
		set((state) => ({
			watchlists: state.watchlists.filter((w) => w._id !== id),
		})),

	// ---- Theme State ----
	theme: localStorage.getItem("theme") || "light",
	setTheme: (theme) => {
		localStorage.setItem("theme", theme);
		set({ theme });
	},
	toggleTheme: () => {
		const current = get().theme;
		const newTheme = current === "dark" ? "light" : "dark";
		localStorage.setItem("theme", newTheme);
		set({ theme: newTheme });
	},
}));

export default useStore;
