import axios from "./axiosInstance.js";

//get stock data from external API by sending symbol as query

export const getStockDatafromExternalAPI = async (symbol) => {
	try {
		const response = await axios.get(
			`/stock/search?symbol=${symbol}`
		)
		return response.data;
	} catch (error) {
		console.error("Error Response:", error.response.data);
		throw new Error(
			error.response.data.message ||
				"Something went wrong with the server."
		);
	}
};
