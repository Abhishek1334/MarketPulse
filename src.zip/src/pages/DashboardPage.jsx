import { useState, useEffect } from "react";
import { getWatchlistsByUser } from "../api/watchlist";
import { showSuccess, showError } from "../utils/toast";
import Header from "../components/Header.jsx";
import SummaryCards from "../components/SummaryCards.jsx";
import Watchlist from "../components/Watchlist.jsx";
import ConfirmationModal from "@/components/ConfirmationModal";
import { DeleteAWatchlist } from "../api/watchlist";
import { PlusIcon } from "lucide-react";
import CreateWatchlist from "../components/CreateWatchlist.jsx";

const DashboardPage = () => {
	const [watchlists, setWatchlists] = useState([]);
	const [loading, setLoading] = useState(false);

	const [isModalOpen, setIsModalOpen] = useState(false);
	const [itemtoDelete, setItemToDelete] = useState(null);
	const [showForm, setShowForm] = useState(false);

	const handleCancel = () => {
		setIsModalOpen(false);
		setItemToDelete(null);
	}

	const handleConfirmDelete = () => {
		
		if(!itemtoDelete){
			return;
		}

		try{
			DeleteAWatchlist(itemtoDelete);
			setWatchlists(watchlists.filter((watchlist) => watchlist._id !== itemtoDelete));
			showSuccess("Watchlist deleted.");
		} catch (error) {
			console.error("Error deleting watchlist:", error);
			showError("Something went wrong with the server.");
		}


		setIsModalOpen(false);
		setItemToDelete(null);
	}

	useEffect(() => {
		const fetchWatchlists = async () => {
			setLoading(true);
			try {
				const fetchedWatchlists = await getWatchlistsByUser();
				setWatchlists(fetchedWatchlists);
				setLoading(false);
			} catch (error) {
				console.error("Error fetching watchlists:", error);
				showError("Failed to fetch watchlists.");
			}
		};

		fetchWatchlists();
	}, []);

	return (
		<div className="p-15">
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4 ">
				<Header />
				<SummaryCards watchlists={watchlists} loading={loading} />
			</div>
			<div className="mt-9">
				<div
					className="text-[var(--text-950)] font-semibold mb-4 flex place-self-end bg-[var(--background-300)] rounded-lg p-3 hover:bg-[var(--secondary-400)] hover:cursor-pointer hover:text-[var(--text-900)] text-sm hover:scale-101 transition-all duration-75 ease-in"
					onClick={() => setShowForm(true)}
				>
					Create New Watchlist{" "}
					<PlusIcon className="ml-2 place-self-center size-4 font-black" />
				</div>
				{showForm && (
					<CreateWatchlist
						onClose={() => setShowForm(false)}
						onCreate={(newList) =>
							setWatchlists((prev) => [...prev, newList])
						}
					/>
				)}

				<Watchlist
					watchlists={watchlists}
					setWatchlists={setWatchlists}
					loading={loading}
					onDelete={(watchlistId) => {
						setItemToDelete(watchlistId);
						setIsModalOpen(true);
					}}
				/>
			</div>
			{isModalOpen && (
				<ConfirmationModal
					onConfirm={handleConfirmDelete}
					onCancel={handleCancel}
				/>
			)}
		</div>
	);
};

export default DashboardPage;
