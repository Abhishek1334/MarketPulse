import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { LoginUser } from "../api/auth.js";
import useStore from "../context/Store.js";
import { showSuccess, showError } from "../utils/toast";

const LoginPage = () => {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const navigate = useNavigate();
	const login = useStore((state) => state.login);
	const user = useStore((state) => state.user);

	useEffect(() => {
		if (user) navigate("/dashboard");
	}, [user, navigate]);

	const handleChange = (e) => {
		const { name, value } = e.target;
		if (name === "email") setEmail(value);
		if (name === "password") setPassword(value);
	};

	const handleSubmit = async (e) => {
		e.preventDefault();

		if (!email || !password) {
			showError("All the fields are required.");
			return;
		}

		setIsLoading(true);
		try {
			const data = await LoginUser(email, password);
			const { user, token } = data;
			login({ user, token });
			showSuccess("Login successful.");
			navigate("/dashboard");
		} catch (error) {
			showError(error.message || "Login failed.");
		} finally {
			setIsLoading(false);
		}
	};

	return (
		<div className="bg-[var(--accent-100)] flex flex-col h-screen justify-center items-center px-4">
			<div className="bg-[var(--accent-200)] shadow-lg p-8 rounded-2xl max-w-sm w-full">
				<h1 className="text-3xl font-bold mb-6 text-center text-[var(--text-900)]">
					Login
				</h1>
				<form className="flex flex-col gap-4" onSubmit={handleSubmit}>
					<input
						type="email"
						name="email"
						value={email}
						placeholder="Email"
						onChange={handleChange}
						className="inputField"
						required
						autoComplete="email"
					/>
					<input
						type="password"
						name="password"
						value={password}
						placeholder="Password"
						onChange={handleChange}
						className="inputField"
						required
						autoComplete="current-password"
					/>
					<button
						type="submit"
						className="formButton"
						disabled={isLoading}
					>
						{isLoading ? (
							<div className="flex justify-center items-center">
								<div className="loader"></div>
							</div>
						) : (
							"Login"
						)}
					</button>
				</form>
				<p className="mt-4 text-center text-sm text-[var(--text-950)]">
					Don't have an account?{" "}
					<Link
						to="/register"
						className="text-[var(--secondary-600)]  font-bold  hover:underline"
					>
						Register here
					</Link>
				</p>
			</div>
		</div>
	);
};

export default LoginPage;
