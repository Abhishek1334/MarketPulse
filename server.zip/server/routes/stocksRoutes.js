import express from "express";
import {
	getStockData,
	getStockDataforWatchlist,
	getStockChartData,
	searchStock
} from "../controllers/externalStockController.js";
const router = express.Router();

router.get("/getStock", getStockData);

router.get("/getStockforWatchlist", getStockDataforWatchlist);

router.get("/chart", getStockChartData);

router.get("/search", searchStock);

export default router;