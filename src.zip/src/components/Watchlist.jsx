import WatchlistCard from "./WatchlistCard";
import { useState } from "react";

const Watchlist = ({ watchlists, setWatchlists, loading, onDelete }) => {

	const handleNameChange = (id, newName) => {
		setWatchlists((prevWatchlists) =>
			prevWatchlists.map((w) =>
				w._id === id ? { ...w, name: newName } : w
			)
		);
	};



	return (
		<div className="mt-9 p-10 bg-[var(--background-100)] shadow-md rounded-lg relative">
			
			{loading ? (
				<div className="flex items-center justify-center h-32">
					<div className="loader"></div>
				</div>
			) : watchlists.length === 0 ? (
				<div className="text-center text-gray-500 p-6">
					<p>No watchlists available.</p>
				</div>
			) : (
				<ul className="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
					{watchlists.map((watchlist) => (
						<WatchlistCard
							key={watchlist._id}
							watchlist={watchlist}
							onNameUpdate={(newName) =>
								handleNameChange(watchlist._id, newName)
							}
							onDelete={onDelete}
						/>
					))}
				</ul>
			)}
		</div>
	);
};

export default Watchlist;
